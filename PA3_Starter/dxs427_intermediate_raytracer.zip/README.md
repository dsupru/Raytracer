Completed all requirements for 1st intermediate submission.

Had to change CMake file in order to compile on a Mac.
Bacause of that, my CMake might not work on Windows, so I am not including it.

In particular, find_package(OpenMP) was not working properly.
I remove that and manually added lookup directories for that package.
Also I had to install llvm because apple-supplied Clang is too old and doesn't have openMP support.
